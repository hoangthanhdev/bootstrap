<?php	
	header("Content-Type: text/html; charset=utf-8");
	define('NGANLUONG_URL', 'https://www.nganluong.vn/checkout.php');
	define('RECEIVER','demo@nganluong.vn'); // Email tài khoản Ngân Lượng
	define('MERCHANT_ID', '36680'); // Mã kết nối
	define('MERCHANT_PASS', 'matkhauketnoi'); // Mật khẩu kết nối 
	
?>


	