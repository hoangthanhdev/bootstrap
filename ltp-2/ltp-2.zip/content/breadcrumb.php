<ol class="breadcrumb" id="xem">
    <li class="breadcrumb-item"><a href="https://lytaphim.com/" target="_plank">Trang Chủ</a><i class="fa fa-angle-double-right mx-2" aria-hidden="true"></i></li>
    <li class="breadcrumb-item active">kamen rider</li>
</ol>