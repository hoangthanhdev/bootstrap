<div class="container text-center">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<h1>TRANG WEB KHÔNG TỒN TẠI</h1>
			<img src="https://images.alphacoders.com/476/thumb-1920-476980.png" alt="Lỗi 404" class="img-responsive">
		</div>
	</div>
</div>