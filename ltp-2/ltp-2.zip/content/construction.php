<div class="container text-center">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<h1>TRANG WEB ĐANG XÂY DỰNG. BẠN VUI LÒNG QUAY LẠI SAU</h1>
			<img src="http://www.archerrealty.co.za/background.jpg" alt="website construction" class="img-responsive">
		</div>
	</div>
</div>