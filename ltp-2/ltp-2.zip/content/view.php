<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<?php if($data_server==2){?>
		<video class="afterglow video" id="myvideo" width="1280" height="720" poster="<?php echo $img_movie;?>" data-skin="dark">
<!-- 		<?php
if(strpos($headers[8],'404') === false){?>
      <source type="video/mp4" src="<?php echo $sd;?>" />
      <source type="video/mp4" src="<?php echo $hd;?>" data-quality="hd" />
<?php }else{ ?>
  <source type="video/mp4" src="<?php echo $hd;?>" />
<?php }?> -->
      <source type="video/mp4" src="https://archive.org/download/ltp-movie/KamenRiderBuildTheMovie-BeTheOne-Hd-Fb-1.m4v" />
      <source type="video/mp4" src="https://archive.org/download/test-soft/KamenRiderBuildTheMovie-BeTheOne-Hd.mp4" data-quality="hd" />
		</video>
	<?php } ?>
	<?php if($data_server==1){?>
		<div class="embed-responsive embed-responsive-16by9">
		  <iframe class="embed-responsive-item" src="//www.ok.ru/videoembed/910191037146" allowfullscreen></iframe>
		</div>
	<?php }?>
	</div>
</div>

<div class="row server">
	<div class="col-xs-12 col-sm-8 col-md-6 col-lg-4 col-sm-push-2 col-md-push-3 col-lg-push-4">
		<div class="btn-group btn-group-lg">
		    <a href="?view=xem&server=1" title="Server 1" class="btn btn-primary <?php if($data_server==1) echo "disabled"?>"><?php if($data_server==1) echo "Bạn đang xem - "?>Server 1</a>
		    <a href="?view=xem&server=2" title="Server 2" class="btn btn-primary <?php if($data_server==2) echo "disabled"?>"><?php if($data_server==2) echo "Bạn đang xem - "?>Server 2</a>
		  </div>
	</div>
</div>