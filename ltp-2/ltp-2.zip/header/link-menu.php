<li class="dropdown">
	<a target="_blank" href="https://lytaphim.com/the-loai" class="dropdown-toggle" data-toggle="dropdown">Siêu nhân Nhật<b class="caret"></b></a>
	<ul class="dropdown-menu">
			<li><a target="_blank" href="https://lytaphim.com/tag/tong-hop-sieu-nhan-nhat"><i class="fas fa-caret-right"></i>Super Sentai</a></li>
			<li><a target="_blank" href="https://lytaphim.com/tag/tong-hop-kamen-rider"><i class="fas fa-caret-right"></i>Kamen Rider</a></li>
			<li><a target="_blank" href="https://lytaphim.com/tag/tong-hop-sieu-nhan-ultraman"><i class="fas fa-caret-right"></i>Ultra Man</a></li>
	</ul>
</li>
<li class="dropdown">
	<a target="_blank" href="https://lytaphim.com/the-loai" class="dropdown-toggle" data-toggle="dropdown">Siêu nhân Mỹ<b class="caret"></b></a>
	<ul class="dropdown-menu">
			<li><a target="_blank" href="https://lytaphim.com/tag/tong-hop-sieu-nhan-my"><i class="fas fa-caret-right"></i>Power Ranger</a></li>
	</ul>
</li>
<li><a target="_blank" href="https://lytaphim.com/sieu-nhan-phim-le">Phim lẻ Siêu Nhân</a></li>
<li><a target="_blank" href="https://lytaphim.com/sieu-nhan-phim-bo">Phim Bộ Siêu Nhân</a></li>