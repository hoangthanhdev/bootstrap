<li class="dropdown">
	<a href="/the-loai" class="dropdown-toggle" data-toggle="dropdown">Siêu nhân Nhật<b class="caret"></b></a>
	<ul class="dropdown-menu">
			<li><a href="/sieu-nhan-phim-bo"><i class="fas fa-caret-right"></i>Super Sentai</a></li>
			<li><a href="/sieu-nhan-phim-bo"><i class="fas fa-caret-right"></i>Kamen Rider</a></li>
			<li><a href="/sieu-nhan-phim-bo"><i class="fas fa-caret-right"></i>Ultra Man</a></li>
	</ul>
</li>
<li class="dropdown">
	<a href="/the-loai" class="dropdown-toggle" data-toggle="dropdown">Siêu nhân Mỹ<b class="caret"></b></a>
	<ul class="dropdown-menu">
			<li><a href="/sieu-nhan-phim-bo"><i class="fas fa-caret-right"></i>Power Ranger</a></li>
	</ul>
</li>
<li><a href="/sieu-nhan-phim-le">Phim lẻ Siêu Nhân</a></li>
<li><a href="/sieu-nhan-phim-bo">Phim Bộ Siêu Nhân</a></li>