			<nav class="navbar navbar-default navbar-inverse menu" role="navigation">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!-- <div class="logo">
							<a class="navbar-brand" href="#">
								<img src="https://www.thuvienaz.net/wp-content/uploads/2018/07/logo.png" alt="">
							</a>				
						</div>-->
						<a class="navbar-brand" href="#">LYTA PHIM</a>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<?php require_once "link-menu.php"; ?>
						</ul>
<!-- 						<div class="nav navbar-nav navbar-right search">
        <div class="searchbar">
          <input class="search_input" type="text" name="" placeholder="Nhập tên phim ...">
          <a href="#" class="search_icon"><i class="fas fa-search"></i></a>
        </div>
</div> -->
					</div><!-- /.navbar-collapse -->
				</div>
			</nav> <!-- end menu -->
<!-- <div class="container text-center">
	<img src="https://www.thuvienaz.net/wp-content/themes/dooplay/images/banner-home.jpg" alt="" class="img-responsive">
</div> -->